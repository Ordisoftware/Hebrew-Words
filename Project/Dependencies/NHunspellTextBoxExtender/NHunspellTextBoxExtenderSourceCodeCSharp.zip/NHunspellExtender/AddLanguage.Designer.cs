﻿using System;
using System.Diagnostics;

namespace NHunspellExtender
{
  [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
  public partial class AddLanguage : System.Windows.Forms.Form
  {

    // Form overrides dispose to clean up the component list.
    [DebuggerNonUserCode()]
    protected override void Dispose(bool disposing)
    {
      try
      {
        if ( disposing && components is not null )
        {
          components.Dispose();
        }
      }
      finally
      {
        base.Dispose(disposing);
      }
    }

    // Required by the Windows Form Designer
    private System.ComponentModel.IContainer components;

    // NOTE: The following procedure is required by the Windows Form Designer
    // It can be modified using the Windows Form Designer.  
    // Do not modify it using the code editor.
    [DebuggerStepThrough()]
    private void InitializeComponent()
    {
      this.txtName = new System.Windows.Forms.TextBox();
      this.Label1 = new System.Windows.Forms.Label();
      this.Label2 = new System.Windows.Forms.Label();
      this.txtAff = new System.Windows.Forms.TextBox();
      this.Label3 = new System.Windows.Forms.Label();
      this.txtDic = new System.Windows.Forms.TextBox();
      this.cmdAff = new System.Windows.Forms.Button();
      this.cmdDic = new System.Windows.Forms.Button();
      this.cmdSubmit = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(69, 6);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(224, 20);
      this.txtName.TabIndex = 0;
      // 
      // Label1
      // 
      this.Label1.AutoSize = true;
      this.Label1.Location = new System.Drawing.Point(22, 9);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(38, 13);
      this.Label1.TabIndex = 1;
      this.Label1.Text = "Name:";
      // 
      // Label2
      // 
      this.Label2.AutoSize = true;
      this.Label2.Location = new System.Drawing.Point(12, 35);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(48, 13);
      this.Label2.TabIndex = 3;
      this.Label2.Text = "Aff Path:";
      // 
      // txtAff
      // 
      this.txtAff.Location = new System.Drawing.Point(69, 32);
      this.txtAff.Name = "txtAff";
      this.txtAff.ReadOnly = true;
      this.txtAff.Size = new System.Drawing.Size(224, 20);
      this.txtAff.TabIndex = 2;
      // 
      // Label3
      // 
      this.Label3.AutoSize = true;
      this.Label3.Location = new System.Drawing.Point(12, 61);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(51, 13);
      this.Label3.TabIndex = 5;
      this.Label3.Text = "Dic Path:";
      // 
      // txtDic
      // 
      this.txtDic.Location = new System.Drawing.Point(69, 58);
      this.txtDic.Name = "txtDic";
      this.txtDic.ReadOnly = true;
      this.txtDic.Size = new System.Drawing.Size(224, 20);
      this.txtDic.TabIndex = 4;
      // 
      // cmdAff
      // 
      this.cmdAff.Image = global::NHunspellExtender.My.Resources.Resources.folder_go;
      this.cmdAff.Location = new System.Drawing.Point(299, 30);
      this.cmdAff.Name = "cmdAff";
      this.cmdAff.Size = new System.Drawing.Size(29, 23);
      this.cmdAff.TabIndex = 6;
      this.cmdAff.UseVisualStyleBackColor = true;
      this.cmdAff.Click += new System.EventHandler(this.cmdAff_Click);
      // 
      // cmdDic
      // 
      this.cmdDic.Image = global::NHunspellExtender.My.Resources.Resources.folder_go;
      this.cmdDic.Location = new System.Drawing.Point(299, 56);
      this.cmdDic.Name = "cmdDic";
      this.cmdDic.Size = new System.Drawing.Size(29, 23);
      this.cmdDic.TabIndex = 7;
      this.cmdDic.UseVisualStyleBackColor = true;
      this.cmdDic.Click += new System.EventHandler(this.cmdDic_Click);
      // 
      // cmdSubmit
      // 
      this.cmdSubmit.Location = new System.Drawing.Point(253, 85);
      this.cmdSubmit.Name = "cmdSubmit";
      this.cmdSubmit.Size = new System.Drawing.Size(75, 23);
      this.cmdSubmit.TabIndex = 8;
      this.cmdSubmit.Text = "Submit";
      this.cmdSubmit.UseVisualStyleBackColor = true;
      this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
      // 
      // AddLanguage
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(333, 118);
      this.Controls.Add(this.cmdSubmit);
      this.Controls.Add(this.cmdDic);
      this.Controls.Add(this.cmdAff);
      this.Controls.Add(this.Label3);
      this.Controls.Add(this.txtDic);
      this.Controls.Add(this.Label2);
      this.Controls.Add(this.txtAff);
      this.Controls.Add(this.Label1);
      this.Controls.Add(this.txtName);
      this.Name = "AddLanguage";
      this.Text = "Add a New Language";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.TextBox txtAff;
    internal System.Windows.Forms.Label Label3;
    internal System.Windows.Forms.TextBox txtDic;
    internal System.Windows.Forms.Button cmdAff;
    internal System.Windows.Forms.Button cmdDic;
    internal System.Windows.Forms.Button cmdSubmit;
  }
}