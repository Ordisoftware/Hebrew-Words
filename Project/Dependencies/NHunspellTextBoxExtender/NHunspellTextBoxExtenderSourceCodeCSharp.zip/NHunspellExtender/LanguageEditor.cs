﻿using System;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace NHunspellExtender
{

  public class LanguageEditor : UITypeEditor
  {

    public override UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
    {
      return UITypeEditorEditStyle.DropDown;
    }

    public override object EditValue(System.ComponentModel.ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      // Get an IWindowsFormsEditorService.
      IWindowsFormsEditorService editor_service = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));


      // If we failed to get the editor service, return the value.
      if ( editor_service is null )
        return value;

      string strValue = value as string;

      if ( strValue is null )
        return value;

      var newListBox = new LanguageListBox(editor_service, strValue);

      editor_service.DropDownControl(newListBox);

      // Add the Item to the registry
      Microsoft.Win32.RegistryKey regKey;
      regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NHunspellTextBoxExtender\Languages", true);

      regKey.SetValue("Default", newListBox.SelectedItem);

      regKey.Close();
      regKey.Dispose();

      return newListBox.SelectedItem;
    }
  }
}