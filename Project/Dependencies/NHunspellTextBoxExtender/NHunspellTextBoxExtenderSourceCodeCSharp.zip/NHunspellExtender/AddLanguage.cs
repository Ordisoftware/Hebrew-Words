﻿using System;

namespace NHunspellExtender
{
  public partial class AddLanguage
  {

    private System.Windows.Forms.DialogResult _result;

    public AddLanguage()
    {

      // This call is required by the designer.
      InitializeComponent();

      // Add any initialization after the InitializeComponent() call.
      _result = System.Windows.Forms.DialogResult.Cancel;
    }

    private void cmdAff_Click(object sender, EventArgs e)
    {
      var newDialog = new System.Windows.Forms.OpenFileDialog();

      newDialog.Title = "Select the Aff file";
      newDialog.Filter = "Aff Files (*.aff)|*.aff|All Files (*.*)|*.*";
      newDialog.FilterIndex = 1;
      if ( newDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK )
      {
        txtAff.Text = newDialog.FileName;
      }
    }

    private void cmdDic_Click(object sender, EventArgs e)
    {
      var newDialog = new System.Windows.Forms.OpenFileDialog();

      newDialog.Title = "Select the Dic file";
      newDialog.Filter = "Dic Files (*.dic)|*.dic|All Files (*.*)|*.*";
      newDialog.FilterIndex = 1;
      if ( newDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK )
      {
        txtDic.Text = newDialog.FileName;
      }
    }

    public System.Windows.Forms.DialogResult Result
    {
      get
      {
        return _result;
      }
    }

    private void cmdSubmit_Click(object sender, EventArgs e)
    {
      if ( string.IsNullOrEmpty(txtAff.Text) | string.IsNullOrEmpty(txtDic.Text) | string.IsNullOrEmpty(txtName.Text) )
      {
        System.Windows.Forms.MessageBox.Show("You must enter all 3 values");
        return;
      }

      _result = System.Windows.Forms.DialogResult.OK;
      Hide();
    }
  }
}