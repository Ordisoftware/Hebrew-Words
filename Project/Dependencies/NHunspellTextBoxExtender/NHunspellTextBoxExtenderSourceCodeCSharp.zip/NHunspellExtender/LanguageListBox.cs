﻿using System;
using System.Windows.Forms.Design;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NHunspellExtender
{

  public class LanguageListBox : System.Windows.Forms.ListBox
  {

    // The editor service displaying us.
    private IWindowsFormsEditorService m_EditorService;


    public LanguageListBox(IWindowsFormsEditorService editor_service, string Value) : base()
    {
      Click += LanguageListBox_Click;
      m_EditorService = editor_service;

      LoadLanguages(Value);
    }

    private void LoadLanguages(string Value = "")
    {
      Items.Clear();

      // Get all languages in list
      Microsoft.Win32.RegistryKey regKey;
      regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NHunspellTextBoxExtender\Languages");

      string[] languages = regKey.GetValue("LanguageList") as string[];

      foreach ( var language in languages )
        Items.Add(language);

      regKey.Dispose();

      Items.Add("<Add a new language>");

      for ( int i = 0, loopTo = Items.Count - 1; i <= loopTo; i++ )
      {
        if ( Conversions.ToBoolean(Operators.ConditionalCompareObjectEqual(Items[i], Value, false)) )
        {
          SelectedIndex = i;
          break;
        }
      }
    }

    private void LanguageListBox_Click(object sender, EventArgs e)
    {
      if ( Conversions.ToBoolean(Operators.ConditionalCompareObjectEqual(SelectedItem, "<Add a new language>", false)) )
      {
        var newAddLang = new AddLanguage();

        newAddLang.ShowDialog();

        if ( newAddLang.Result == System.Windows.Forms.DialogResult.Cancel )
        {
          return;
        }

        // Add the Item to the registry
        Microsoft.Win32.RegistryKey regKey;
        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NHunspellTextBoxExtender\Languages", true);

        string[] languages = regKey.GetValue("LanguageList") as string[];

        bool boolFound = false;
        foreach ( var language in languages )
        {
          if ( ( language ?? "" ) == ( newAddLang.txtName.Text ?? "" ) )
          {
            boolFound = true;
            break;
          }
        }

        if ( !boolFound )
        {
          Array.Resize(ref languages, Information.UBound(languages) + 1 + 1);
          languages[Information.UBound(languages)] = newAddLang.txtName.Text;

          regKey.SetValue("LanguageList", languages, Microsoft.Win32.RegistryValueKind.MultiString);
        }

        var paths = new string[2];

        paths[0] = newAddLang.txtAff.Text;
        paths[1] = newAddLang.txtDic.Text;

        regKey.SetValue(newAddLang.txtName.Text, paths, Microsoft.Win32.RegistryValueKind.MultiString);

        regKey.Close();
        regKey.Dispose();

        int selection = Items.Add(newAddLang.txtName.Text);
        SelectedIndex = selection;
      }
      else
      {
        // Check if the paths are still valid
        var regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\NHunspellTextBoxExtender\Languages", true);

        string[] paths = regKey.GetValue(Conversions.ToString(SelectedItem)) as string[];

        if ( paths is null )
        {
          System.Windows.Forms.MessageBox.Show("Aff and Dic files are missing");

          string[] languages = regKey.GetValue("LanguageList") as string[];
          var newLanguageList = new string[( Information.UBound(languages) )];
          int count = 0;

          foreach ( var language in languages )
          {
            if ( Conversions.ToBoolean(Operators.ConditionalCompareObjectNotEqual(language, SelectedItem, false)) )
            {
              newLanguageList[count] = language;
              count += 1;
            }
          }

          regKey.SetValue("LanguageList", newLanguageList, Microsoft.Win32.RegistryValueKind.MultiString);
          regKey.DeleteValue(Conversions.ToString(SelectedItem));

          LoadLanguages();

          regKey.Close();
          regKey.Dispose();

          return;
        }
        else
        {
          foreach ( var path in paths )
          {
            if ( !System.IO.File.Exists(path) )
            {
              System.Windows.Forms.MessageBox.Show("Aff and Dic files are missing");

              string[] languages = regKey.GetValue("LanguageList") as string[];
              var newLanguageList = new string[( Information.UBound(languages) )];
              int count = 0;

              foreach ( var language in languages )
              {
                if ( Conversions.ToBoolean(Operators.ConditionalCompareObjectNotEqual(language, SelectedItem, false)) )
                {
                  newLanguageList[count] = language;
                  count += 1;
                }
              }

              regKey.SetValue("LanguageList", newLanguageList, Microsoft.Win32.RegistryValueKind.MultiString);
              regKey.DeleteValue(Conversions.ToString(SelectedItem));

              LoadLanguages();

              regKey.Close();
              regKey.Dispose();

              return;
            }
          }
        }

      }

      if ( m_EditorService is not null )
        m_EditorService.CloseDropDown();
    }


  }
}